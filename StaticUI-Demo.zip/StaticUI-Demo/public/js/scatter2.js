//$(
	
	function initScatterPlot() {
		
		var margin = {top: 0, right: 10, bottom: 10, left: 30};
    var width = 675 - margin.left - margin.right;
    var height = 680 - margin.top - margin.bottom;
	
	//add svg with margin !important
	//this is svg is actually group
	/*var svg = d3.select("body").append("svg")
				.attr("width",width+margin.left+margin.right)
				.attr("height",height+margin.top+margin.bottom)
				.append("g")  //add group to leave margin for axis
				.attr("transform","translate("+margin.left+","+margin.top+")");*/
	
	   // svg.remove();

	var svg = d3.select("#my_dataviz")
  .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
  .append("g")
    .attr("transform",
          "translate(" + margin.left + "," + margin.top + ")");
	//the code above should be same
	
	var yScale = d3.scaleLinear()
    .domain([-5, 5])
    .range([ 0, height ]);
	
	var xScale = d3.scaleLinear()
    .domain([-5, 5])
    .range([ 0, width ]);
	
	//add x and y axis
	var yAxis = d3.axisLeft(yScale);
	svg.append("g").call(yAxis).attr("transform","translate("+width/2+",0)");
	

	var xAxis = d3.axisBottom(xScale);/*.tickFormat("");remove tick label*/
	svg.append("g").call(xAxis).attr("transform", "translate(0,"+height/2+")");
	
	//add label for x axis and y axis
	svg.append("text").text("Y Label")
		.attr("x",0-height/2)
		.attr("y",0-margin.left)
		.attr("dy","4em")
      	.style("text-anchor", "middle")
		.attr("transform","rotate(-90)");
	svg.append("text").text("X Label")
		.attr("x",width/2)
		.attr("y",height+margin.bottom)
      	.style("text-anchor", "middle");
	
	var svgObj = new Object();
	svgObj.svg = svg;
	svgObj.xScale = xScale;
	svgObj.yScale = yScale;
	
	return svgObj;
		
	}
	
	function drawScatterPlot(svgObj,dataset,dataset1) {


	 var svg = svgObj.svg;
	 var xScale = svgObj.xScale;
	 var yScale = svgObj.yScale;
	//svg.remove();
	// var margin = svgObj.margin;


	
/*	var datasett = [[5, 20], [480, 90], [-250, 50], [100, 33], [330, -95],
                [410, -12], [475, 44], [25, 67], [-85, 21], [220, 88],[-85, -21]];
	var dataset1 = [[4, 4], [-2, 3], [-3, -2], [3, -1], [1, -2],
                [3, -1], [4, 1], [-1, -3], [-2, 1], [2, -4],[-3, -2]];*/
	//for each d, d[0] is the first num, d[1] is the second num
	//set y scale
	//var yScaleee = d3.scaleLinear().rangeRound([0,height]).domain([d3.max(dataset,function(d){return Math.abs(d[1]);}),- d3.max(dataset,function(d){return Math.abs(d[1]);})]);//show negative
	//add x axis
	//var xScalee = d3.scaleLinear().rangeRound([0,width]).domain([-d3.max(dataset,function(d){return Math.abs(d[0]);}),d3.max(dataset,function(d){return Math.abs(d[0]);})]);//scaleBand is used for  bar chart
	
	console.log("d"+dataset[0]);
	console.log("d1"+dataset1[0]);

	if( (dataset[0][0] == dataset1[0][0] ) && (dataset[0][1] == dataset1[0][1] ))
	{
		
		var barpadding = 2;
		//svg.selectAll("circle").data(dataset).exit().remove();
		var circles = svg.selectAll("circle2").data(dataset).enter().append("circle");
		circles.attr("cx",function(d){
				  return xScale(d[0]);//i*(width/dataset.length);
				  })
		.attr("cy",function(d){
			return yScale(d[1]);
		})//for bottom to top
		.attr("r", 4);
		circles.attr("fill",function(d){
			return "green";
		});
		
	    svg.selectAll("circle2").data(dataset).exit().remove();
	    return; 
	}	
	var barpadding = 2;
	//svg.selectAll("circle").data(dataset).exit().remove();
	var circles = svg.selectAll("circle2").data(dataset).enter().append("circle");
	circles.attr("cx",function(d){
			  return xScale(d[0]);//i*(width/dataset.length);
			  })
	.attr("cy",function(d){
		return yScale(d[1]);
	})//for bottom to top
	.attr("r", 4);
	circles.attr("fill",function(d){
		return "red";
	});
	
    svg.selectAll("circle2").data(dataset).exit().remove();

var circlesG = svg.selectAll("circle1").data(dataset1).enter().append("circle");
	circlesG.attr("cx",function(d){
			  return xScale(d[0]);//i*(width/dataset.length);
			  })
	.attr("cy",function(d){
		return yScale(d[1]);
	})//for bottom to top
	.attr("r", 4);
	circlesG.attr("fill",function(d){
		return "blue";
	});
	    svg.selectAll("circle1").data(dataset1).exit().remove();


}


//});
