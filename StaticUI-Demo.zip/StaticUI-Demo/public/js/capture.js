$(function() {
  var canvas = document.getElementById('canvas');
  var ctx = canvas.getContext('2d');
  var ctx1 = document.getElementById('canvas1').getContext('2d');
  var ctx2 = document.getElementById('canvas2').getContext('2d');
  var ctx3 = document.getElementById('canvas3').getContext('2d');
  var ctx4 = document.getElementById('canvas4').getContext('2d');
  var ctx5 = document.getElementById('canvas5').getContext('2d');
  var ctx6 = document.getElementById('canvas6').getContext('2d');
  var ctx7 = document.getElementById('canvas7').getContext('2d');
  var ctx8 = document.getElementById('canvas8').getContext('2d');
  var ctx9 = document.getElementById('canvas9').getContext('2d');
  //var ctx10 = document.getElementById('canvas10').getContext('2d');
  var video = document.getElementById('video1');
  var text0 = "NifteeAI. Know how you are perceived. Don't let perception become reality. AI for a better you !";
  var text1 = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut";
  var text2 = "labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco";
  var text3 = "laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate";
var dataset = [[4, 4], [-2, 3], [-3, -2], [3, -1], [1, -2],
                [3, -1], [4, 1], [-1, -3], [-2, 1], [2, -4],[-3, -2]];
var dataset0 = [[4, 4]];
var dataset1 = [[3, 2]];
var dataset2 = [[2, 4]];
var dataset3 = [[1, 3]];
var dataset4 = [[-1, 4]];
var dataset5 = [[-2, 4]];
var dataset6 = [[-3, -1]];
var dataset7 = [[-4, 4]];
var dataset8 = [[1, 1]];
var dataset9 = [[2, 3]];
var dataset10 = [[3, 1]];
var dataset11 = [[4, 1]];
var dataset12 = [[-1, 2]];
var dataset13 = [[-2, -4]];
var dataset14 = [[-3, 1]];
var dataset15 = [[-4, -2]];

var datasetNLP0 = [[1, 4]];
var datasetNLP1 = [[3, 2]];
var datasetNLP2 = [[3, 4]];
var datasetNLP3 = [[1, -2]];
var datasetNLP4 = [[-1, 4]];
var datasetNLP5 = [[-2, 2]];
var datasetNLP6 = [[-3, -1]];
var datasetNLP7 = [[2, 4]];
var datasetNLP8 = [[1, 1]];
var datasetNLP9 = [[2, -2]];
var datasetNLP10 = [[3, -2]];
var datasetNLP11 = [[4, 1]];
var datasetNLP12 = [[-1, 4]];
var datasetNLP13 = [[-2, -2]];
var datasetNLP14 = [[-1, 1]];
var datasetNLP15 = [[-4, 1]];
var emotion = ["Amused", "Glad","Pleased","Calm" , "Sleepy" , "Tired", "Tense" ,"Angry" , "Afraid" , "Sad" ,"Gloomy", "Bored",
				"Content" ,"Serene" , "Miserable" , "Tense"];
var nemotion = ["Amused", "Glad","Pleased","Calm" , "Sleepy" , "Tired", "Tense" ,"Angry" , "Afraid" , "Sad" ,"Gloomy", "Bored",
				"Content" ,"Serene" , "Miserable" , "Tense"];
	var counter = 0;
	var second = 0;

  /*video.addEventListener('play', function() {
    var $this = this; //cache
    (function loop() {
      if (!$this.paused && !$this.ended) {
        ctx.drawImage($this, 0, 0);
        setTimeout(loop, 1000 / 30); // drawing at 30fps
      }
    })();
  }, 0);*/

video.addEventListener('pause', (event) => {
  console.log('The Boolean paused property is now true. Either the ' +
  'pause() method was called or the autoplay attribute was toggled.');
});

video.addEventListener('play', () => {
  /*function step() {
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height)
    requestAnimationFrame(step)
  }
  requestAnimationFrame(step);
	})*/
	
	function step() {
	//	console.log('pause:'+video.paused);
		if(video.paused ==true)
		 return 0;
	
		const fps = 3;
		
		//console.log('playing');
	

    

 setTimeout(() => {
    requestAnimationFrame(step);
  }, 1000 / fps);

    if( (counter % 3 ) == 0 ){
	
		if(counter >=9)
		  ctx9.drawImage(canvas8, 0, 0, canvas8.width, canvas8.height);	
	
		if(counter >=8)
		  ctx8.drawImage(canvas7, 0, 0, canvas7.width, canvas7.height);
	
	    if(counter >=7)
		  ctx7.drawImage(canvas6, 0, 0, canvas7.width, canvas7.height);
	
	    if(counter >=6)
		  ctx6.drawImage(canvas5, 0, 0, canvas6.width, canvas6.height);
	
	    if(counter >=5)
		  ctx5.drawImage(canvas4, 0, 0, canvas5.width, canvas5.height);
	
	    if(counter >=4)
		  ctx4.drawImage(canvas3, 0, 0, canvas4.width, canvas4.height);
	
	    if(counter >=3)
		 ctx3.drawImage(canvas2, 0, 0, canvas3.width, canvas3.height);
	
	    if(counter >=2)
		 ctx2.drawImage(canvas1, 0, 0, canvas2.width, canvas2.height);
	
	    if(counter >=1)
		 ctx1.drawImage(canvas, 0, 0, canvas1.width, canvas1.height);
	
	}
   
	
	    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
		//autoDownloadCanvas();
	
	  counter++;
//console.log(counter);
}  
  requestAnimationFrame(step);


var intervalId = window.setInterval(function(){
  console.log("every second:"+second);
if(video.paused ==true)
		 return 0;
	
	generateNLPText();
	refreshRightSide();
	second++;
	
}, 1000);

function generateNLPText(){
	
	//if  ( (counter % 5 ) > 0 )
	if  ( (second % 5 ) > 0 )
	 return 0;

// Every 5th second change nlp text
var randomInt = randomIntFromInterval(0,3);
document.getElementById('nlp-text').textContent = eval('text'+randomInt);
  console.log(eval('text'+randomInt));

	
}

function refreshRightSide(){
	
	var rem = counter % 10;
	
	//if  ( (counter % 10 ) > 0 )
	//if  ( counter < 10 || (counter % 10 ) !=3  )
	if  ( second < 10 || (second % 5 ) !=3  )
	 return 0;

// Every 10 second refresh right side
var randomInt = randomIntFromInterval(0,15);
 // console.log(dataset[randomInt]);
var x = eval('dataset'+randomInt);
var y = eval('datasetNLP'+randomInt);
  console.log(x+","+y);

  

//drawScatterPlot(svgObj,dataset[randomInt]);
//drawScatterPlot(svgObj,x);
$('#my_dataviz').empty();

var svgObj = initScatterPlot();


drawScatterPlot(svgObj,x,y);

$('#fScores').text(x);
$('#fEmotion').text(emotion[randomInt]);

$('#nScores').text(y);
$('#nEmotion').text(emotion[randomInt]);


	
}

async function autoDownloadCanvas() {
  let link = document.getElementById('link');
  var filename = "example"+counter+".jpg";
  //link.setAttribute('download', 'example.png');
  link.setAttribute('download', filename);
  link.setAttribute('href', canvas.toDataURL("image/jpg"));
  link.click();
}

function randomIntFromInterval(min, max) { // min and max included 
  return Math.floor(Math.random() * (max - min + 1) + min)
}

});


var svgObj = initScatterPlot();

	})
	


$(document).on("change", ".file_multi_video", function(evt) {
  var $source = $('#video_here');
  $source[0].src = URL.createObjectURL(this.files[0]);
  $source.parent()[0].load();
});

